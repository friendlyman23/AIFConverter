#include <windows.h>
#include <stdio.h>
#include <math.h>
#include <limits.h>
#include "converter.h"
#include "converter.cpp"

#pragma pack(push,1)
    struct wav_riff_chunk
    {
	char ID[ID_WIDTH]; // "RIFF"
	uint32 ChunkSize; // Size of the file less 4 bytes for this field and
			  //	4 bytes for the ID field
	char Format[ID_WIDTH]; // "WAVE"
    };

    struct wav_format_chunk
    {
	char ID[ID_WIDTH]; // "fmt "
	int32 ChunkSize; // 16 if PCM sample
	int16 FormatTag; // 1 if PCM
	uint16 Channels; // COMM->NumChannels
	uint32 SampleRate; // COMM->SampleRate
	uint32 AverageBytesPerSec; // == SampleRate * NumChannels * BitsPerSample/8
	uint16 BlockAlign; // == NumChannels * BitsPerSample/8
	uint16 BitsPerSample; // COMM->SampleSize
    };

    struct wav_data_chunk
    {
	char ID[ID_WIDTH]; // "data"
	int32 ChunkSize; // NumSamples * NumChannels * BitsPerSample/8
    };

    struct wav_cue_point
    {
	int32 Identifier;
	int32 Position;
	char CorrespondingDataChunk[ID_WIDTH];
	int32 ChunkStart;
	int32 BlockStart;
	int32 SampleOffset;
    };

    struct wav_cue_chunk
    {
	char ID[ID_WIDTH]; // "cue "
	int32 ChunkSize;
	int32 TotalCuePoints;
    };

    struct wav_list_header
    {
	char ListID[ID_WIDTH]; // "list"
	int32 ChunkSize; // 4 for TypeID + size of remainder of chunks in adtl
	char TypeID[ID_WIDTH]; // "adtl"
    };

    struct wav_label_chunk
    {
	char ID[ID_WIDTH]; // "labl"
	int32 ChunkSize;
	int32 CorrespondingCueIdentifier;
    };

    struct wav_instrument_chunk
    {
	char ID[ID_WIDTH]; // "inst"
	int32 ChunkSize;
	uint8 UnshiftedNote;
	int8 FineTune;
	int8 Gain;
	uint8 LowNote;
	uint8 HighNote;
	uint8 LowVelocity;
	uint8 HighVelocity;
    };


    // Chunks with trailing data arrays 
    //	  "data": size of chunk will be sizeof wav_data_chunk + number of samples
    //
    //	  "cue ": size of chunk will be sizeof wav_cue_chunk + 
    //		    (sizeof wav_cue_point * wav_cue_chunk->TotalCuePoints)
    //
    //	  "list": size of chunk will be sizeof wav_list_header +
    //		    (sizeof wav_label_chunk * wav_cue_chunk->TotalCuePoints)
    //		    (total String Lengths from MarkerChunks) +
    //		    [since each CueIdentifier should be null-terminated] NumMarkerChunks 
    //			(one null char per marker chunk)

#pragma pack(pop)

int WinMain(HINSTANCE Instance, 
        HINSTANCE PrevInstance, 
        PSTR CmdLine, 
        int CmdShow)
{
    // Load .aif file
    LPCWSTR Aif_Filename = L"AIF_SC~1.AIF";
    uint8 *Aif_FileStart;

    HANDLE HeapHandle = GetProcessHeap();
    LARGE_INTEGER Aif_FileSize;
    Aif_FileSize.QuadPart = 0;

    if(HeapHandle)
    {
        Aif_FileStart = (uint8 *)Win32_GetAifFilePointer(Aif_Filename, &Aif_FileSize);
    }
    else
    {
	char DebugPrintStringBuffer[MAX_STRING_LEN];
	sprintf_s(DebugPrintStringBuffer, sizeof(DebugPrintStringBuffer), 
		"\nERROR:\n\t"
		"At program start, failed to get HeapHandle, so exited");
	OutputDebugStringA((char *)DebugPrintStringBuffer);
	exit(1);
    }

    // Allocate memory
    arena *Scratchpad = ArenaAlloc(Megabytes(1));

    // Declare pointer into Aif file that we move around as we parse. Hereafter,
    //	  any variable prefixed "Aif_" refers to data in the .aif file that
    //	  we're converting
    uint8 *Aif_FileIndex = Aif_FileStart;

    // Every .aif file that meets spec starts with a Form chunk; if we don't
    //	  find it, the Form chunk parsing function exits the program
    converted_form_chunk *Converted_FormChunk = PushStruct(Scratchpad, converted_form_chunk);
    int64 Aif_FileSize_IntVersion = (int64) Aif_FileSize.QuadPart;
    ParseFormChunk(Aif_FileIndex, Converted_FormChunk, Aif_FileSize_IntVersion);
    Aif_FileIndex = Converted_FormChunk->Aif_SubChunksStart;

    // Excepting a very few edge cases, .aif files that meet spec will 
    //	  always have one Common chunk and one Sound Data chunk 
    //	  (hereafter referred to as "IMportant chunks").
    //
    //	  So we next look for these, and as we scan the file for them, store 
    //	  pointers to other chunks we find along the way (these are 
    //	  hereafter referred to as "UNimportant chunks").
    uint8 *LastByteInFile = (uint8 *)( (Aif_FileStart + Aif_FileSize_IntVersion) - 1);

    // We're gonna need the Common and Sound Data chunks if the .aif file meets 
    //	  spec, so just allocate for them here and then we can parse them as soon as
    //	  we find them in the while loop below
    converted_common_chunk *Converted_CommonChunk = PushStruct(Scratchpad, converted_common_chunk);
    converted_sound_data_chunk *Converted_SoundDataChunk = PushStruct(Scratchpad, converted_sound_data_chunk);
    
    // We'll likely find unimportant chunks too, but we don't parse them until
    //	  after we've done our initial scan and validated the file. So for now
    //	  we just keep a count of how many we find and store their addresses.
    unimportant_chunk_header *UnimportantChunkDirectory = PushArray(Scratchpad, unimportant_chunk_header, MAX_UNIMPORTANT_CHUNKS);
    int CountOfUnimportantChunks = 0;
    int CountOfEachChunkType[HASHED_CHUNK_ID_ARRAY_SIZE] = {0};


    // Scan the .aif file
    while(Aif_FileIndex <= LastByteInFile)
    {
	// Figure out which chunk we're looking at
	generic_chunk_header *Aif_ThisChunksHeader = (generic_chunk_header *)Aif_FileIndex;
	chunk HashedID = (chunk)GPerfHasher(Aif_ThisChunksHeader->ID, ID_WIDTH);

	// If we encounter a second Form chunk, the file is busted, so exit
	if(HashedID == FORM_CHUNK)
	{
	    char DebugPrintStringBuffer[MAX_STRING_LEN];
	    sprintf_s(DebugPrintStringBuffer, sizeof(DebugPrintStringBuffer), 
		    "\nERROR:\n\t"
		    "\n\t\tThis .aif file contains more than one Form chunk,"
		    "\n\t\twhich is not permitted by the .aif specification."
		    "\n\t\tTherefore, your .aif file appears to be corrupted."
		    "\n\nThis program will now exit.");
	    OutputDebugStringA((char *)DebugPrintStringBuffer);
	    exit(1);
	}

	// If it's the Common chunk, parse it
	else if(HashedID == COMMON_CHUNK)
	{
	    ParseCommonChunk(Aif_FileIndex, Converted_CommonChunk);
	}
	// If it's the Sound Data chunk, parse it
	else if(HashedID == SOUND_DATA_CHUNK)
	{
	    ParseSoundDataChunk(Aif_FileIndex, Converted_SoundDataChunk);
	}
	
	// Otherwise it's an unimportant chunk. For now we just store the
	//    address; we don't parse it until we've validated the file
	else if(GPerfIDLookup(Aif_ThisChunksHeader->ID, ID_WIDTH))
	{
	    if( CountOfUnimportantChunks < (MAX_UNIMPORTANT_CHUNKS - 1) )
	    {
		UnimportantChunkDirectory[CountOfUnimportantChunks].HashedID = HashedID;
		UnimportantChunkDirectory[CountOfUnimportantChunks].Aif_Chunk = Aif_FileIndex;
		CountOfUnimportantChunks++;
	    }
	    else
	    {
	    char DebugPrintStringBuffer[MAX_STRING_LEN];
	    sprintf_s(DebugPrintStringBuffer, sizeof(DebugPrintStringBuffer), 
		    "\nERROR:\n\t"
		    "\n\t\t.aif file contains more than %d unimportant"
		    "\n\t\tchunks, which is beyond what this program expected."
		    "\n\nThis program will now exit.", MAX_UNIMPORTANT_CHUNKS);
	    OutputDebugStringA((char *)DebugPrintStringBuffer);
	    exit(1);
	    }
	}

	// If we enter this block, a chunk ID we read does not meet 
	//    .aif spec, so exit
	else
	{
	    char DebugPrintStringBuffer[MAX_STRING_LEN];
	    sprintf_s(DebugPrintStringBuffer, sizeof(DebugPrintStringBuffer), 
		    "\nERROR:\n\t"
		    "\n\t\tThis .aif file's metadata appears to be corrupted."
		    "\n\nThis program will now exit.");
	    OutputDebugStringA((char *)DebugPrintStringBuffer);
	    exit(1);

	}
	CountOfEachChunkType[HashedID]++;
	Aif_FileIndex = Aif_ThisChunksHeader->Data;
	Aif_FileIndex += FlipEndianness(Aif_ThisChunksHeader->ChunkSize);
    }

    // Validate file
    ValidateAif(CountOfEachChunkType, Converted_CommonChunk, Converted_SoundDataChunk);

    // Now that we know the .aif file is valid, begin to calculate the size of the buffer
    //	  we'll need to write the .wav file we're going to output
    int BytesNeededForWav = 0;

    // Start by including the sizes of chunks whose sizes are known at compile time
    BytesNeededForWav += sizeof(wav_riff_chunk);
    BytesNeededForWav += sizeof(wav_format_chunk);
    BytesNeededForWav += sizeof(wav_data_chunk);

    // And include the number of sample bytes we found in the .aif file
    //	  (likely to be around a million)
    int TotalSampleBytes = (Converted_CommonChunk->NumSampleFrames *
			    Converted_CommonChunk->NumChannels *
			    (Converted_CommonChunk->SampleSize / BITS_IN_BYTE) );
    BytesNeededForWav += TotalSampleBytes;
    
    // Loop through the array of unimportant chunk pointers we stored when 
    //	  scanning the .aif file. Convert the chunks' data, and along the 
    //	  way, update the BytesNeededForWav total
    for(int i = 0; i < CountOfUnimportantChunks; i++)
    {
	// Figure out which chunk we're looking at
	unimportant_chunk_header ThisChunk = UnimportantChunkDirectory[i];

	switch(ThisChunk.HashedID)
	{
	    case MARKER_CHUNK:
	    {
		// If we encounter a Marker Chunk, that means the resulting .wav file
		//     should almost certainly have:
		//	1.) A Cue chunk that contains several Cues, and
		//	2.) A List chunk that contains several sub-chunks,
		//
		//	The sizes of some of these are known at compile time; others
		//	can't be known until we parse the file.
		BytesNeededForWav += sizeof(wav_cue_chunk);
		BytesNeededForWav += sizeof(wav_list_header);

		converted_marker_chunk *Converted_MarkerChunk = PushStruct(Scratchpad, converted_marker_chunk);
		UnimportantChunkDirectory[i].Converted_Chunk = (uint8 *)Converted_MarkerChunk;
		ParseMarkerChunk(ThisChunk.Aif_Chunk, Converted_MarkerChunk);
		
		if(Converted_MarkerChunk->TotalMarkers > 0)
		{
		    BytesNeededForWav += (sizeof(wav_cue_point) * Converted_MarkerChunk->TotalMarkers);
		    BytesNeededForWav += (sizeof(wav_label_chunk) * Converted_MarkerChunk->TotalMarkers);

		    Converted_MarkerChunk->Converted_MarkersStart = 
				PushArray(Scratchpad, converted_marker, 
					    Converted_MarkerChunk->TotalMarkers);
		    ParseMarkers(Converted_MarkerChunk, Scratchpad, 
				Converted_CommonChunk->NumSampleFrames,
				&BytesNeededForWav);
		}
	    } break;

	    case INSTRUMENT_CHUNK:
	    {
		converted_instrument_chunk *Converted_InstrumentChunk = 
				    PushStruct(Scratchpad, converted_instrument_chunk);
		UnimportantChunkDirectory[i].Converted_Chunk = (uint8 *)Converted_InstrumentChunk;
		ParseInstrumentChunk(ThisChunk.Aif_Chunk, Converted_InstrumentChunk);

		// It's very easy to update the BytesNeededForWav value here
		//    as compared with all the hoops we jumped through above
		BytesNeededForWav += sizeof(wav_instrument_chunk);
	    } break;

	    case FILLER_CHUNK: 
	    {
		// todo: do we need to worry about including empty bytes in
		//    the .wav to maintain page alignment?
		filler_chunk *FillerChunk = PushStruct(Scratchpad, filler_chunk);
		UnimportantChunkDirectory[i].Converted_Chunk = (uint8 *)FillerChunk;
		ParseFillerChunk(ThisChunk.Aif_Chunk, FillerChunk);
	    } break;

	    default:
	    {
		char DebugPrintStringBuffer[MAX_STRING_LEN];
		sprintf_s(DebugPrintStringBuffer, sizeof(DebugPrintStringBuffer), 
			"\nERROR:\n\t"
			"\n\t\tEncountered unexpected chunk when converting"
			"\n\t\t.aif chunk data."
			"\n\nThis program will now exit.");
		OutputDebugStringA((char *)DebugPrintStringBuffer);
		exit(1);

	    } break;
	}
    }











    


    


    



    




    return(0);
}






    













